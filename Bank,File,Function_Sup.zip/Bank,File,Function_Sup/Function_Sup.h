#pragma once
#include "iostream"
#include "string"
#include "vector"
#include "iomanip"
using namespace std;

void notice(string sentence,string horizontal, string vertical);